package lesson12.lab12_2.employeeinfo;

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
