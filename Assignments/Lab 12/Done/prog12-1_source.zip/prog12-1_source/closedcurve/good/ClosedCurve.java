package prog7_2_soln.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
