package prog4_4_soln;

abstract public class ClosedCurve {
	abstract double computeArea();

}
