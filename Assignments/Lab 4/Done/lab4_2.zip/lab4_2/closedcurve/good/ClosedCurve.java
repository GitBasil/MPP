package lesson7.lab7_2.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
