package prog4_7_startup.employeeinfo;

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
