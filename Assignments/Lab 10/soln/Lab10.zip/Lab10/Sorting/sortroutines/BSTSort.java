package sortroutines;

import runtime.Sorter;

public class BSTSort extends Sorter {
	int[] arr;
	public int[] sort(int[] arr){
		this.arr = arr;
		//selectionSort();
		return arr;
	}
}
