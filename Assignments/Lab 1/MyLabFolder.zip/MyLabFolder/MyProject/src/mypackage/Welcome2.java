package mypackage;
//import javax.swing.JOptionPane;

public class Welcome2 {

	public static void main(String[] args) {
		System.out.println(welcome());
		//JOptionPane.showMessageDialog(null, "Hello John!");
	}
	
	public static String welcome() {
		return "Welcome";
	}
}
