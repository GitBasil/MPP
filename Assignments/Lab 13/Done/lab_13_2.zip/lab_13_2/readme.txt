place javadb_files directory at top level of C: drive (so that
batch files will work)