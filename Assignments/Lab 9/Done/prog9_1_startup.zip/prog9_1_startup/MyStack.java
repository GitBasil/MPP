package prog9_1_startup;

public class MyStack {
	private MyStringLinkedList list;
	public MyStack() {
		list = new MyStringLinkedList();
	}
	
	public String pop() {
		//implement
		return null;
	}
	public String peek() {
		//implement
		return null;
	}
	
	public void push(String s) {
		//implement
	}
}
