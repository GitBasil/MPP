package prog7_4_soln;

public class Main {
	public static void main(String[] args) {
		DivideSort dSort = new DivideSort();
		String s = "abced";
		System.out.print(dSort.divideSort(s));
	}

}
