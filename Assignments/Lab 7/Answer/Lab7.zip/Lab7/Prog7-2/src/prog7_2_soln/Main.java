package prog7_2_soln;
public class Main {
	public static void main(String[] args) {
		MinSort msort = new MinSort();
		System.out.println(msort.sort("zwxuabfkafutbbbb"));
	}

}
