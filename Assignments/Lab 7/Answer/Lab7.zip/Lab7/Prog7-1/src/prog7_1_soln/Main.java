package prog7_1_soln;
public class Main {
	public static void main(String[] args) {
		Exponential exp = new Exponential();
		System.out.println(exp.power(2, 10));
	}
}