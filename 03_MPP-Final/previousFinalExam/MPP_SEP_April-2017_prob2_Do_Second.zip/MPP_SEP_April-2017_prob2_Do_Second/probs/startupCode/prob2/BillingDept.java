package prob2;

public class BillingDept {
	//implement
	
	public String monthlyReport() {
		//not implemented
		return null;
	}
}
