package prob1;

public class Majors {
	public static final String CS = "Computer Science";
	public static final String ENG = "English";
	public static final String CH = "Chinese";
	public static final String PH = "Physics";
	public static final String SOC = "Sociology";
	public static final String CHEM = "Chemistry";
	public static final String PSY = "Psychology";
}
