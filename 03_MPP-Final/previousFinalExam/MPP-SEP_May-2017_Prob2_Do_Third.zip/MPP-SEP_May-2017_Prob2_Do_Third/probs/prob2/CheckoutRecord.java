package prob2;

public class CheckoutRecord {
	
	
}
