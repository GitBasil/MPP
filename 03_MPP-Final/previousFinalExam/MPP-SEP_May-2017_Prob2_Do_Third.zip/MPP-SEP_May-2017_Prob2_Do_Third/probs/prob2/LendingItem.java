package prob2;

public class LendingItem {
	
}
