package prob1;

import java.util.List;

public class Admin {
	public static List<Student> obtainHonorRoll(List<Student> list) {
		//implement
		return null;
	}
}
