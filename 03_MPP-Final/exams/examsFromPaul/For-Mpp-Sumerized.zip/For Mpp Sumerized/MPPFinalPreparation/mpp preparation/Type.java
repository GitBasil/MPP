package Second.Test.Example.Dish;

public enum Type {
	 MEAT, FISH, OTHER
}
