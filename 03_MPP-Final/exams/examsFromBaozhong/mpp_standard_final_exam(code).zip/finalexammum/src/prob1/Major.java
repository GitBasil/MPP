package prob1;

public class Major {
	public static final String COMPUTER_SCIENCE = "CS";
	public static final String EDUCATION_SCIENCE = "ES";
	public static final String SOCIOLOGY = "SOCIOLOGY";
	public static final String BASIC_PSYCHOLOGY = "BP";
}
