package prob5;

public class SeminarsConducted {

}
