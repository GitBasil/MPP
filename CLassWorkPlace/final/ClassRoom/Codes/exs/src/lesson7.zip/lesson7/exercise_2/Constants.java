package lesson7.exercise_2;

public class Constants {
	public static final String COMPANY = "Microsoft";
	public static final int SALES_TARGET = 20000000;
}
