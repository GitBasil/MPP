package lesson10.exercise_2_soln;

@BugReport(assignedTo="Corazza", severity=1)
public class BadCode {
	
	public int add(int x, int y) {
		return x - y;
		
	}
}
